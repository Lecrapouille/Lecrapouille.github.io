#include <scicos/scicos_block.h>
#include </Applications/scilab-3.1.1/routines/machine.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

#define xclose(fd)		{ close(fd); fd = -1; }
// SCICOS EVENTS
#define SCICOS_INIT_PHASE	4
#define SCICOS_EVENT_PHASE	3
#define SCICOS_LOOP_PHASE	1
#define SCICOS_END_PHASE	5
// SERIAL PORT FIELDS
#define PARITY_NONE		0
#define PARITY_ODD		1
#define PARITY_EVEN		2
#define SOFTWARE_FLOW_CONTROL	2
#define HARDWARE_FLOW_CONTROL	1
#define NO_FLOW_CONTROL		0
#define SIZE_TAB_SPEED		34
// ENUMERATOR for the 'scicos_block->ipar' array
#define E_SPEED			0
#define E_DATABITS		1
#define E_PARITY		2
#define E_STOPBITS		3
#define E_FLOWCONTROL		4
#define E_BUFFER_READ		5
#define E_BUFFER_WRITE		5
#define E_SIZE_NAME		6
#define E_BEGIN_NAME		7
#define E_END_NAME		ipar[E_SIZE_NAME + E_BEGIN_NAME]


extern  int C2F(cvstr)  __PARAMS((integer *,integer *,char *,integer *,unsigned long int));

static	      int     fd = -1;	/**< Port's file descriptor */
static struct termios term;	/**< Current console config */
static unsigned char  in[64];
static unsigned char  out[64];

static struct termios oldterm;	/**< Save the original console config */
static const  int     tab_speed[SIZE_TAB_SPEED] = {
  50, B50, 75, B75, 110, B110, 134, B134, 150, B150,
  200, B200, 300, B300, 600, B600, 1200, B1200, 1800,
  B1800, 2400, B2400, 4800, B4800, 9600, B9600, 19200,
  B19200, 38400, B38400, 57600, B57600, 0, B0
};
static const  int     tab_cs[] = {CS5, CS6, CS7, CS8};
static float       reussite = 0;
 static float     cycle = 0;


/** Quick function to initialize the serial port
 **
 ** static int	init_serial(const char *portname)
 ** {
 **  speed_t	input_speed;
 **  speed_t	output_speed;
 **  struct termios tty_struct;
 **  int		fd;
 **
 **  if ((fd = open(portname, O_RDWR | O_NONBLOCK)) == -1)
 **    return -1;
 **  tcgetattr(fd, &tty_struct);
 **  input_speed = cfgetispeed(&tty_struct);
 **  output_speed = cfgetospeed(&tty_struct);
 **  cfsetospeed(&tty_struct, B9600);
 **  cfsetispeed(&tty_struct, B50);
 **  tty_struct.c_cflag |= CS8;
 **  tty_struct.c_cflag |= PARENB;
 **  tty_struct.c_cflag &= ~(PARODD);
 **  tty_struct.c_iflag |= INPCK;
 **  tty_struct.c_cflag &= ~(IXON | IXOFF);
 **  tcsetattr(fd, TCSADRAIN, &tty_struct);
 **  return fd;
 ** }
 */

static int	set_speed(int speed, struct termios *term)
{
  int		i = 0;

  while (i < SIZE_TAB_SPEED && tab_speed[i] != speed)
    i += 2;
  if (i >= SIZE_TAB_SPEED
      || cfsetispeed(term, tab_speed[i + 1]) == -1
      || cfsetospeed(term, tab_speed[i + 1]) == -1)
    {
      sciprint("Vitesse %d Non valide\n", speed);
      return -1;
    }
  sciprint("Vitesse de transmition : %d\n", speed);
  return 0;
}

static int	set_parity(int parity, struct termios *term)
{
  switch (parity)
    {
    case PARITY_NONE:
      sciprint("Pas de parite\n");
      term->c_cflag &= ~PARENB;
      term->c_iflag &= ~INPCK;
      break;
    case PARITY_EVEN:
      sciprint("Parite paire\n");
      term->c_cflag |= PARENB;
      term->c_cflag &= ~PARODD;
      term->c_iflag |= INPCK;
      break;
    case PARITY_ODD:
      sciprint("Parite impaire\n");
      term->c_cflag |= PARENB;
      term->c_cflag |= PARODD;
      term->c_iflag |= INPCK;
      break;
    default:
      sciprint("Invalid parity of serial port");
      return -1;
    }
  return 0;
}

static int	set_num_data_bits(int bits, struct termios *term)
{
  term->c_cflag &= ~CSIZE;
  term->c_iflag &= ~ISTRIP;
  if (bits >= 5 && bits <= 8)
    {
      sciprint("%d bits de donnees\n", bits);
      term->c_cflag |= tab_cs[bits - 5];
    }
  else
    {
      sciprint("%d is an invalid number of bits:\n", bits);
      return -1;
    }
  return 0;
}

static int	set_num_stop_bits(int bits, struct termios *term)
{
  switch (bits)
    {
    case 2:
      sciprint("2 bits de stop\n");
      term->c_cflag |= CSTOPB;
      break;
    case 1:
      sciprint("1 bit de stop\n");
      term->c_cflag &= ~CSTOPB;
      break;
    default:
      sciprint("invalid number of stop bits:\n");
      return -1;
   }
  return 0;
}

/** FIXME: chuis pas sur si c bon */
static int	set_flow_control(int control, struct termios *term)
{
  if (control == SOFTWARE_FLOW_CONTROL)
    {
      sciprint("SOFT FLOW CONROL\n");
      term->c_cflag |= (IXON | IXOFF);
    }
  else
    {
      sciprint("pas de SOFT FLOW CONROL\n");
      term->c_cflag &= ~(IXON | IXOFF);
    }

  if (control == HARDWARE_FLOW_CONTROL)
    {
      sciprint("HARDWARE FLOW CONROL\n");
      term->c_cflag |= CRTSCTS;
    }
  else
    {
      sciprint("pas de HARD FLOW CONROL\n");
      term->c_cflag &= ~CRTSCTS;
    }
  return 0;
}

/**
 * Exemple de ipar: {3,'A','B','C',9600,8,2,1,0,r};
 * 3: taille du nom du port
 * 'A','B','C': nom du port (code ascii scilab) 63 char max
 * 9600: vitesse du port
 * 8: nombre de bits de donnees
 * 2: parite paire
 * 1: nombre de bits de stop
 * 0: aucun controle materiel et logiciel
 * r: nombre de char a lire
 * w: nombre de char a ecrire
 */
static int	serialport_new(const int *ipar)
{
  char		portname[64] = "";
  int		job = 1;

  F2C(cvstr)(&(ipar[E_SIZE_NAME]), &(ipar[E_BEGIN_NAME]), portname, &job, strlen(portname));
  portname[ipar[E_SIZE_NAME]] = '\0';

  // Attention: Read non blocant !!!
  if ((fd = open(portname, O_RDWR | O_NONBLOCK)) == -1)
    {
      sciprint("Can not open the serial port '%s'\n", portname);
      return -1;
    }
  sciprint("Ouverture du port serie reussie '%s'\n", portname);

  if (tcgetattr(fd, &oldterm) == -1 || tcgetattr(fd, &term) == -1)
    {
      sciprint("Can not get the termios structure\n");
      xclose(fd);
      return -1;
    }

  if (set_speed(ipar[E_SPEED], &term) == -1
      || set_num_data_bits(ipar[E_DATABITS], &term) == -1
      || set_parity(ipar[E_PARITY], &term) == -1
      || set_num_stop_bits(ipar[E_STOPBITS], &term) == 1
      || set_flow_control(ipar[E_FLOWCONTROL], &term) == -1)
    {
      sciprint("ya erreur\n");
      xclose(fd);
      return -1;
    }

  if (tcsetattr(fd, TCSANOW, &term) == -1)
    {
      printf("Can not set the termios structure (errno: ");
      switch (errno)
	{
	case EBADF: printf("EBADF)\n"); break;
	case EINTR: printf("EINTR)\n"); break;
	case EINVAL: printf("EINVAL)\n"); break;
	case ENOTTY: printf("ENOTTY)\n"); break;
	}
      xclose(fd);
      return -1;
    }
  return 0;
}

/** Scicos function
 *
 * Ecrire dans le port serie un message de nb carcarteres (nb * 1
 * octet) + 1 char de terminaison du message.
 *
 * nb est un param de scicos_block->ipar (position E_NUM_CHAR_WRITE).
 *
 * @warning bien que block->inptr soient des flottants leurs valeurs
 * doivent tenir sur 8 bits.
 */
void		serialport_write(scicos_block *block, int flag)
{
  int		i;

  if (flag != SCICOS_LOOP_PHASE)
    return ;

  for (i = 0; i < block->ipar[E_BUFFER_WRITE]; ++i)
    {
      out[i] = block->inptr[0][i];
      block->outptr[0][i] = block->inptr[0][i];
    }
  write(fd, out, block->ipar[E_BUFFER_WRITE]);
}

/** Scicos function */
void		serialport_read(scicos_block *block, int flag)
{
  int		res, nb, i;
  unsigned char c;

  switch (flag)
    {
    case SCICOS_INIT_PHASE:
      reussite = 0;
      cycle = 0;
      if (serialport_new(block->ipar) == -1)
	sciprint("\nInitialisation of the serial port failed !!\n");
      else
	sciprint("\nInitialisation of the serial succeeded !!\n");
      break;
    case SCICOS_END_PHASE:
      if (tcsetattr(fd, TCSANOW, &oldterm) == -1)
	sciprint("Je ne peux pas restaurer l'ancienne config de la console\n");
      xclose(fd);
      break;
    case SCICOS_LOOP_PHASE:
      if (fd == -1)
	return;
      i = 0;
      while (i < 13)
	{
	  ++cycle;
	  if ((nb = read(fd, &c, 1)) == -1)
	    {
	      if (errno != EAGAIN)
		sciprint("Erreur avec fonction read : %s\n", strerror(errno));
	    }
	  in[2] = in[1];
	  in[1] = in[0];
	  in[0] = c;
	  if (in[0] == 10 && in[2] < 4)
	    {
	      sciprint("J'ai chope la val %d %d (taux reus=%f)\n", in[2], in[1],3*reussite/cycle);
	      block->outptr[0][0] = in[2];
	      block->outptr[0][1] = in[1];
	      block->outptr[0][2] = in[0];
	      ++reussite;
	      return ;
	    }
	  ++i;
	}
      sciprint("TIME OUT\n");
      break;
    }
}
