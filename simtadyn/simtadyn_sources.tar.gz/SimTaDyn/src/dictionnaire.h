#ifndef DICTIONNAIRE_H
#define DICTIONNAIRE_H

#include "header.h"
#include "mot.h"
#include "hash.h"
#include "pile.h"
#include "mot.h"
#include "memoire.h"
#include "screenshot.h"
#include "selection.h"

void creer_dico_min();

#endif /* DICTIONNAIRE_H */
