#ifndef HEADER_H
#define HEADER_H

#include "header_forth.h"
#include "affichage.h"

#endif /* HEADER_H */
