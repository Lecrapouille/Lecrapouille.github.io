#ifndef PROMPT_H
#define PROMPT_H

#include "header.h"
#include "string_util.h"
#include "selection.h"

void action_prompt(GtkEntry *entry, const gchar * texte);

#endif
