#ifndef TRIANGULER_H
#define TRIANGULER_H

#include "header.h"
#include "opgl.h"
#include "memoire.h"
#include "normal.h"

void trianguler(t_liste);
void trianguler_carte();

#endif
