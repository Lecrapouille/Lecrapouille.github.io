#include <unistd.h>

int syndex_send_synchro(int fd)
{
  static const int data[1];
  return write (fd, &data, 1);
}
